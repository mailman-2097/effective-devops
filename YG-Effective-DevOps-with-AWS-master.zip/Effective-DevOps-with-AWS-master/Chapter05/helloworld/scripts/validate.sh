#!/bin/sh
curl -I localhost:3000  
